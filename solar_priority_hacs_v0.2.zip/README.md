# Solar Priority

Home Assistant HACS custom integration for solar-first EV charging and secondary water-heater control.

## Intended setup
- Shelly Pro 3EM grid power: `sensor.shellypro3em_c8f09e82ede4_teho`
- Wallbox current: `number.wallbox_pulsarplus_sn_244017_suurin_latausvirta`
- Wallbox pause/resume: `switch.wallbox_pulsarplus_sn_244017_keskeyta_jatka`
- Wallbox pause/resume: `switch.wallbox_pulsarplus_sn_244017_keskeyta_jatka`
- Water heater: `switch.shellypro3_ec6260882ad0_output_0`
- Nord Pool: `sensor.nord_pool_fi_current_price`

## Logic
1. Solar surplus: EV first.
2. Water heater (3 kW) only if enough surplus remains after EV charging.
3. Cheap Nord Pool hour: EV at configured maximum; water heater may run if the configured grid-import ceiling permits it.
4. No solar/cheap hour: EV is paused and water heater is off.
5. The integration never switches 1/3 phase. Select `Kesä (1-vaihe)` or `Talvi (3-vaihe)` after physically changing the Wallbox installation.

The Shelly sign convention is assumed to be negative W = export to grid, as seen in the supplied setup.

## Installation
Copy `custom_components/solar_priority` to Home Assistant `config/custom_components/solar_priority`, restart, then add **Solar Priority** from Settings → Devices & services.

For HACS, publish this folder as a GitHub repository and add the repository in HACS as a custom repository of type **Integration**.

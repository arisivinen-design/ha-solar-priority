from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from .const import DOMAIN, MODE_SUMMER, MODE_WINTER

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback):
    async_add_entities([SolarModeSelect(hass, entry)])

class SolarModeSelect(SelectEntity):
    _attr_name = "Aurinko-ohjauksen vaihetila"
    _attr_icon = "mdi:ev-station"
    _attr_options = [MODE_SUMMER, MODE_WINTER]

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry):
        self.hass = hass
        self.entry = entry
        self._attr_unique_id = f"{entry.entry_id}_mode"
        self._attr_current_option = hass.data[DOMAIN][entry.entry_id]["mode"]

    async def async_select_option(self, option: str):
        self._attr_current_option = option
        self.hass.data[DOMAIN][self.entry.entry_id]["mode"] = option
        self.async_write_ha_state()

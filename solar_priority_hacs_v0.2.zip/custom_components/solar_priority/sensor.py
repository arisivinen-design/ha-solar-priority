from datetime import timedelta
import asyncio
import math
from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfPower
from homeassistant.core import HomeAssistant
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from .const import *

SCAN_INTERVAL = timedelta(seconds=30)

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback):
    controller = SolarPriorityController(hass, entry)
    hass.data[DOMAIN][entry.entry_id]["controller"] = controller
    async_add_entities([SolarSurplus(controller), SolarState(controller), SolarPrice(controller)])
    await controller.update()
    async_track_time_interval(hass, controller.update, SCAN_INTERVAL)

class SolarPriorityController:
    def __init__(self, hass, entry):
        self.hass = hass
        self.entry = entry
        self.data = entry.data
        self.surplus = 0.0
        self.price = None
        self.state_text = "Käynnistyy"
        self.last_action = None

    def number(self, entity_id, default=0.0):
        s = self.hass.states.get(entity_id)
        if not s or s.state in ("unknown", "unavailable"):
            return default
        try: return float(s.state)
        except (TypeError, ValueError): return default

    async def update(self, _now=None):
        grid = self.number(self.data[CONF_GRID_POWER])
        raw_price = self.number(self.data[CONF_NORD_POOL], math.nan)
        self.price = None if math.isnan(raw_price) else raw_price
        self.surplus = max(0.0, -grid)

        min_a = float(self.data[CONF_MIN_CURRENT]); max_a = float(self.data[CONF_MAX_CURRENT])
        margin = float(self.data[CONF_SURPLUS_MARGIN]); water_power = float(self.data[CONF_WATER_POWER])
        cheap_limit = float(self.data[CONF_CHEAP_PRICE]); grid_limit = float(self.data[CONF_GRID_LIMIT])
        cheap = self.price is not None and self.price <= cheap_limit
        mode = self.hass.data[DOMAIN][self.entry.entry_id]["mode"]
        three_phase = mode == MODE_WINTER
        watts_per_amp = 230.0 * (math.sqrt(3) if three_phase else 1.0)

        # Solar mode: EV always gets priority. Water heater only starts after
        # the EV has been given its maximum available power and surplus remains.
        if self.surplus >= min_a * watts_per_amp + margin:
            amps = min(max_a, max(min_a, math.floor(((self.surplus - margin) / watts_per_amp) * 2) / 2))
            await self.set_wallbox(amps, paused=False)
            ev_power = amps * watts_per_amp
            water_on = self.surplus >= ev_power + water_power + margin
            await self.set_water(water_on)
            self.state_text = f"Aurinko: auto {amps:.1f} A" + (", vesi ON" if water_on else "")
            return

        # Cheap-price mode: charge EV at maximum. Water heater is allowed only
        # when the configured grid-import ceiling would not be exceeded.
        if cheap:
            await self.set_wallbox(max_a, paused=False)
            water_on = max(0.0, grid) + water_power <= grid_limit
            await self.set_water(water_on)
            self.state_text = f"Halpa tunti: auto {max_a:.0f} A" + (", vesi ON" if water_on else "")
            return

        await self.set_water(False)
        await self.set_wallbox(min_a, paused=True)
        self.state_text = "Odotus: ei ylijäämää eikä halpaa tuntia"

    async def set_wallbox(self, amps, paused):
        current_id = self.data[CONF_WALLBOX_CURRENT]
        pause_id = self.data[CONF_WALLBOX_PAUSE]
        # Set current first, then pause/resume. Never write 0 A because the
        # Wallbox entity normally has a minimum of 6 A.
        await self.hass.services.async_call("number", "set_value", {"entity_id": current_id, "value": float(max(amps, 1))}, blocking=True)
        await self.hass.services.async_call("switch", "turn_off" if paused else "turn_on", {"entity_id": pause_id}, blocking=True)

    async def set_water(self, on):
        await self.hass.services.async_call("switch", "turn_on" if on else "turn_off", {"entity_id": self.data[CONF_WATER_SWITCH]}, blocking=True)

class Base(SensorEntity):
    def __init__(self, c):
        self.c = c
        self._attr_should_poll = True
    async def async_update(self):
        await self.c.update()

class SolarSurplus(Base):
    _attr_name = "Aurinko-ohjaus ylijäämä"
    _attr_native_unit_of_measurement = UnitOfPower.WATT
    _attr_icon = "mdi:solar-power"
    def __init__(self,c): super().__init__(c); self._attr_unique_id=f"{c.entry.entry_id}_surplus"
    @property
    def native_value(self): return round(self.c.surplus, 0)

class SolarState(Base):
    _attr_name = "Aurinko-ohjaus tila"
    _attr_icon = "mdi:state-machine"
    def __init__(self,c): super().__init__(c); self._attr_unique_id=f"{c.entry.entry_id}_state"
    @property
    def native_value(self): return self.c.state_text

class SolarPrice(Base):
    _attr_name = "Aurinko-ohjaus Nord Pool hinta"
    _attr_native_unit_of_measurement = "EUR/kWh"
    _attr_icon = "mdi:currency-eur"
    def __init__(self,c): super().__init__(c); self._attr_unique_id=f"{c.entry.entry_id}_price"
    @property
    def native_value(self): return self.c.price
